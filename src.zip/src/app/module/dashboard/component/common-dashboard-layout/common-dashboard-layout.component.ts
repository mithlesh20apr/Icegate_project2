import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-dashboard-layout',
  templateUrl: './common-dashboard-layout.component.html',
  styleUrls: ['./common-dashboard-layout.component.scss']
})
export class CommonDashboardLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
