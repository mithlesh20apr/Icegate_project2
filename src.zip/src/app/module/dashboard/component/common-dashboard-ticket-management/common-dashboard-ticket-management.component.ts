import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-dashboard-ticket-management',
  templateUrl: './common-dashboard-ticket-management.component.html',
  styleUrls: ['./common-dashboard-ticket-management.component.scss']
})
export class CommonDashboardTicketManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
