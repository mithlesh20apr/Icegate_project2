export class Widget{
	icegateId: string;
	roleName: string;
	profileStatus: boolean;
	registrationStatus: boolean;
	ticketManagement: boolean;
	egmStatus: boolean;
	igmStatus: boolean;
	billOfEntryStatus: boolean;
	shippingBillStatus: boolean;
	myIec: boolean;
	teamManagement: boolean;
	igstRefund: boolean;
	exportIncentive: boolean;
	ledger: boolean;
	drafts: boolean;
	notifications: boolean;
	bondAndBg: boolean;
	challansGenerated: boolean;
	foreignRemittance: boolean;
	licenseDetails: boolean
}