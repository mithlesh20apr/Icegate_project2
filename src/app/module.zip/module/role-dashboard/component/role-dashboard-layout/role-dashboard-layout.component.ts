import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-role-dashboard-layout',
  templateUrl: './role-dashboard-layout.component.html',
  styleUrls: ['./role-dashboard-layout.component.scss']
})
export class RoleDashboardLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
