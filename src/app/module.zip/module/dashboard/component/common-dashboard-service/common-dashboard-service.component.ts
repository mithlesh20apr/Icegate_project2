import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-dashboard-service',
  templateUrl: './common-dashboard-service.component.html',
  styleUrls: ['./common-dashboard-service.component.scss']
})
export class CommonDashboardServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
