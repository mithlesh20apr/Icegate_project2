import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-dashboard-registration',
  templateUrl: './common-dashboard-registration.component.html',
  styleUrls: ['./common-dashboard-registration.component.scss']
})
export class CommonDashboardRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
